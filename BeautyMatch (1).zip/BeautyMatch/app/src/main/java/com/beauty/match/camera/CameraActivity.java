package com.beauty.match.camera;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.beauty.match.R;
import com.beauty.match.analysis.SkinToneActivity;
import com.beauty.match.catalog.ProductListActivity;
import com.beauty.match.utils.StorageUtils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class CameraActivity extends AppCompatActivity {

    private static final String TAG = "CameraActivity";

    private LinearLayout btnDemoMode, btnGallery, btnManualColor;

    // Новый API вместо устаревшего startActivityForResult
    private final ActivityResultLauncher<Intent> galleryLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    Uri selectedImage = result.getData().getData();
                    if (selectedImage != null) {
                        handleGalleryResult(selectedImage);
                    }
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_camera);

        btnDemoMode = findViewById(R.id.btn_demo_mode);
        btnGallery = findViewById(R.id.btn_gallery);
        btnManualColor = findViewById(R.id.btn_manual_color);

        btnDemoMode.setOnClickListener(v -> createDemoPhotoAndProceed());
        btnGallery.setOnClickListener(v -> openGallery());
        btnManualColor.setOnClickListener(v -> goToManualInput());
    }

    private void createDemoPhotoAndProceed() {
        File photoFile = new File(StorageUtils.getPhotosFolder(this), "demo_skin.jpg");

        if (!photoFile.exists()) {
            Bitmap bitmap = Bitmap.createBitmap(600, 800, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bitmap);
            Paint paint = new Paint();

            for (int y = 0; y < 800; y++) {
                int r = 240 - y / 20;
                int g = 210 - y / 25;
                int b = 185 - y / 30;
                paint.setColor(Color.rgb(Math.max(r, 180), Math.max(g, 160), Math.max(b, 140)));
                canvas.drawLine(0, y, 600, y, paint);
            }

            try (FileOutputStream out = new FileOutputStream(photoFile)) {
                bitmap.compress(Bitmap.CompressFormat.JPEG, 95, out);
            } catch (IOException e) {
                Toast.makeText(this, "Ошибка создания тестового фото", Toast.LENGTH_SHORT).show();
                return;
            }
        }

        Intent intent = new Intent(this, SkinToneActivity.class);
        intent.putExtra("photo_path", photoFile.getAbsolutePath());
        startActivity(intent);
    }

    private void openGallery() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        galleryLauncher.launch(intent);
    }

    private void handleGalleryResult(Uri selectedImage) {
        String fileName = "gallery_" + System.currentTimeMillis() + ".jpg";
        File destFile = new File(StorageUtils.getPhotosFolder(this), fileName);

        try {
            Bitmap bitmap;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                // Новый API для Android 9+
                android.graphics.ImageDecoder.Source source = 
                        android.graphics.ImageDecoder.createSource(getContentResolver(), selectedImage);
                bitmap = android.graphics.ImageDecoder.decodeBitmap(source);
            } else {
                // Fallback для старых версий
                bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), selectedImage);
            }

            try (FileOutputStream out = new FileOutputStream(destFile)) {
                bitmap.compress(Bitmap.CompressFormat.JPEG, 95, out);
            }

            Intent intent = new Intent(this, SkinToneActivity.class);
            intent.putExtra("photo_path", destFile.getAbsolutePath());
            startActivity(intent);

        } catch (IOException e) {
            Log.e(TAG, "Gallery error", e);
            Toast.makeText(this, "Ошибка загрузки фото", Toast.LENGTH_SHORT).show();
        }
    }

    private void goToManualInput() {
        try {
            Intent intent = new Intent(this, ProductListActivity.class);
            startActivity(intent);
        } catch (Exception e) {
            Log.e(TAG, "Error starting ProductListActivity", e);
            Toast.makeText(this, "Ошибка открытия каталога: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onBackPressed() {
        finish();
    }
}
